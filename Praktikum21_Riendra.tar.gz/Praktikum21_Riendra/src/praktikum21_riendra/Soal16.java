package praktikum21_riendra;

public class Soal16 {
    public static void main(String[] args) {
        int[][] nilai = {
            { 80, 90, 70 },
            { 70, 80, 90 },
            { 90, 70, 80 }
        };

        for (int i = 0; i < nilai.length; i++) {
            int total = 0;
            for (int j = 0; j < nilai[i].length; j++) {
                total += nilai[i][j];
            }
            System.out.println("Rata-rata siswa " + (i + 1) + ": " + (double) total / nilai[i].length);
        }
    }
}
