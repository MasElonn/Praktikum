package praktikum21_riendra;

interface Payable {
    void makePayment(double amount);
    void printReceipt();
}

class CashPayment implements Payable {
    private double amount;

    @Override
    public void makePayment(double amount) {
        this.amount = amount;
    }

    @Override
    public void printReceipt() {
        System.out.println("Cash Payment Receipt");
        System.out.println("Total Bayar: " + amount);
    }
}

class DigitalPayment implements Payable {
    private double amount;
    private String appName;

    public DigitalPayment(String appName) {
        this.appName = appName;
    }

    @Override
    public void makePayment(double amount) {
        this.amount = amount;
    }

    @Override
    public void printReceipt() {
        System.out.println("Digital Payment Receipt");
        System.out.println("Aplikasi Pembayaran: " + appName);
        System.out.println("Jumlah Nominal: " + amount);
    }
}

public class Soal9 {
    public static void main(String[] args) {
        CashPayment cashPayment = new CashPayment();
        cashPayment.makePayment(100000);
        cashPayment.printReceipt();

        System.out.println();

        DigitalPayment digitalPayment = new DigitalPayment("GoPay");
        digitalPayment.makePayment(50000);
        digitalPayment.printReceipt();
    }
}
