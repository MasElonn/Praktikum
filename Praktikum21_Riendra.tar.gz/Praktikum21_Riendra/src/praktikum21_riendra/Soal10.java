package praktikum21_riendra;

class Buku {
    String judul;
    String penulis;
    int harga;

    public Buku(String judul, String penulis, int harga) {
        this.judul = judul;
        this.penulis = penulis;
        this.harga = harga;
    }

    public void tampilkanInfo() {
        System.out.println("Judul: " + judul);
        System.out.println("Penulis: " + penulis);
        System.out.println("Harga: " + harga);
    }
}

public class Soal10 {
    public static void main(String[] args) {
        Buku[] buku = new Buku[3];
        buku[0] = new Buku("Buku 1", "Penulis 1", 100000);
        buku[1] = new Buku("Buku 2", "Penulis 2", 150000);
        buku[2] = new Buku("Buku 3", "Penulis 3", 120000);

        for (Buku b : buku) {
            b.tampilkanInfo();
        }

        Buku bukuTermahal = buku[0];
        for (Buku b : buku) {
            if (b.harga > bukuTermahal.harga) {
                bukuTermahal = b;
            }
        }

        System.out.println("\nBuku termahal:");
        bukuTermahal.tampilkanInfo();
    }
}

