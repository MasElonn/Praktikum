package praktikum21_riendra;

public class Soal14 {
    public static boolean cekPrima(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.println("Apakah 7 bilangan prima? " + cekPrima(7));
        System.out.println("Apakah 10 bilangan prima? " + cekPrima(10));
    }
}
