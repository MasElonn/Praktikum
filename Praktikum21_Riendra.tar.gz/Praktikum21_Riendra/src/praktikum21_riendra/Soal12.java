package praktikum21_riendra;

interface Diskon {
    double hitungDiskon();
}

class Buku12 {
    String judul;
    String penulis;
    int harga;

    public Buku12(String judul, String penulis, int harga) {
        this.judul = judul;
        this.penulis = penulis;
        this.harga = harga;
    }

    public void tampilInfo() {
        System.out.println("Judul: " + judul);
        System.out.println("Penulis: " + penulis);
        System.out.println("Harga: " + harga);
    }
}

class BukuFiksi extends Buku12 implements Diskon {
    public BukuFiksi(String judul, String penulis, int harga) {
        super(judul, penulis, harga);
    }

    @Override
    public double hitungDiskon() {
        return harga * 0.1;
    }
}

class BukuNonFiksi extends Buku12 implements Diskon {
    public BukuNonFiksi(String judul, String penulis, int harga) {
        super(judul, penulis, harga);
    }

    @Override
    public double hitungDiskon() {
        return harga * 0.05;
    }
}

public class Soal12 {
    public static void main(String[] args) {
        BukuFiksi bukuFiksi = new BukuFiksi("Buku Fiksi", "Penulis Fiksi", 100000);
        BukuNonFiksi bukuNonFiksi = new BukuNonFiksi("Buku Non Fiksi", "Penulis Non Fiksi", 120000);

        bukuFiksi.tampilInfo();
        System.out.println("Diskon: " + bukuFiksi.hitungDiskon());
        System.out.println();
        bukuNonFiksi.tampilInfo();
        System.out.println("Diskon: " + bukuNonFiksi.hitungDiskon());
    }
}
