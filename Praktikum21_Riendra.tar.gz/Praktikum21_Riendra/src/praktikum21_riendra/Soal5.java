package praktikum21_riendra;

public class Soal5 {
    public static double hitungRata(int[] nilai) {
        int total = 0;
        for (int n : nilai) {
            total += n;
        }
        return (double) total / nilai.length;
    }

    public static void tampilkanStatus(double rata) {
        if (rata >= 60) {
            System.out.println("Lulus");
        } else {
            System.out.println("Tidak Lulus");
        }
    }

    public static void main(String[] args) {
        int[] nilai = { 70, 80, 60, 90, 50 };
        double rata = hitungRata(nilai);
        System.out.println("Rata-rata: " + rata);
        tampilkanStatus(rata);
    }
}
