package praktikum21_riendra;

class Buku11 {
    String judul;
    String penulis;
    int harga;

    public Buku11(String judul, String penulis, int harga) {
        this.judul = judul;
        this.penulis = penulis;
        this.harga = harga;
    }

    public void tampilInfo() {
        System.out.println("Judul: " + judul);
        System.out.println("Penulis: " + penulis);
        System.out.println("Harga: " + harga);
    }
}

public class Soal11 {
    public static void main(String[] args) {
        Buku11 buku1 = new Buku11("Buku 1", "Penulis 1", 100000);
        Buku11 buku2 = new Buku11("Buku 2", "Penulis 2", 150000);

        buku1.tampilInfo();
        System.out.println();
        buku2.tampilInfo();
    }
}
